// Generated from /Users/matar/School/compiler/Assignment3/OFP.g4 by ANTLR 4.13.1
    // Define name of package for generated Java files. 
    package generated;

import org.antlr.v4.runtime.tree.ParseTreeListener;

/**
 * This interface defines a complete listener for a parse tree produced by
 * {@link OFPParser}.
 */
public interface OFPListener extends ParseTreeListener {
	/**
	 * Enter a parse tree produced by {@link OFPParser#start}.
	 * @param ctx the parse tree
	 */
	void enterStart(OFPParser.StartContext ctx);
	/**
	 * Exit a parse tree produced by {@link OFPParser#start}.
	 * @param ctx the parse tree
	 */
	void exitStart(OFPParser.StartContext ctx);
	/**
	 * Enter a parse tree produced by {@link OFPParser#mainFunc}.
	 * @param ctx the parse tree
	 */
	void enterMainFunc(OFPParser.MainFuncContext ctx);
	/**
	 * Exit a parse tree produced by {@link OFPParser#mainFunc}.
	 * @param ctx the parse tree
	 */
	void exitMainFunc(OFPParser.MainFuncContext ctx);
	/**
	 * Enter a parse tree produced by {@link OFPParser#methodFunc}.
	 * @param ctx the parse tree
	 */
	void enterMethodFunc(OFPParser.MethodFuncContext ctx);
	/**
	 * Exit a parse tree produced by {@link OFPParser#methodFunc}.
	 * @param ctx the parse tree
	 */
	void exitMethodFunc(OFPParser.MethodFuncContext ctx);
	/**
	 * Enter a parse tree produced by {@link OFPParser#stmtBlock}.
	 * @param ctx the parse tree
	 */
	void enterStmtBlock(OFPParser.StmtBlockContext ctx);
	/**
	 * Exit a parse tree produced by {@link OFPParser#stmtBlock}.
	 * @param ctx the parse tree
	 */
	void exitStmtBlock(OFPParser.StmtBlockContext ctx);
	/**
	 * Enter a parse tree produced by {@link OFPParser#argList}.
	 * @param ctx the parse tree
	 */
	void enterArgList(OFPParser.ArgListContext ctx);
	/**
	 * Exit a parse tree produced by {@link OFPParser#argList}.
	 * @param ctx the parse tree
	 */
	void exitArgList(OFPParser.ArgListContext ctx);
	/**
	 * Enter a parse tree produced by {@link OFPParser#exprList}.
	 * @param ctx the parse tree
	 */
	void enterExprList(OFPParser.ExprListContext ctx);
	/**
	 * Exit a parse tree produced by {@link OFPParser#exprList}.
	 * @param ctx the parse tree
	 */
	void exitExprList(OFPParser.ExprListContext ctx);
	/**
	 * Enter a parse tree produced by the {@code assignStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterAssignStmt(OFPParser.AssignStmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code assignStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitAssignStmt(OFPParser.AssignStmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code declareStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterDeclareStmt(OFPParser.DeclareStmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code declareStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitDeclareStmt(OFPParser.DeclareStmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code declareAssignStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterDeclareAssignStmt(OFPParser.DeclareAssignStmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code declareAssignStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitDeclareAssignStmt(OFPParser.DeclareAssignStmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code arrayAccessStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterArrayAccessStmt(OFPParser.ArrayAccessStmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code arrayAccessStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitArrayAccessStmt(OFPParser.ArrayAccessStmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code arrayAssignStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterArrayAssignStmt(OFPParser.ArrayAssignStmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code arrayAssignStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitArrayAssignStmt(OFPParser.ArrayAssignStmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code ifStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterIfStmt(OFPParser.IfStmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code ifStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitIfStmt(OFPParser.IfStmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code whileStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterWhileStmt(OFPParser.WhileStmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code whileStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitWhileStmt(OFPParser.WhileStmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code returnStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterReturnStmt(OFPParser.ReturnStmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code returnStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitReturnStmt(OFPParser.ReturnStmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code callMethodStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterCallMethodStmt(OFPParser.CallMethodStmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code callMethodStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitCallMethodStmt(OFPParser.CallMethodStmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code printStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterPrintStmt(OFPParser.PrintStmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code printStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitPrintStmt(OFPParser.PrintStmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code printlnStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 */
	void enterPrintlnStmt(OFPParser.PrintlnStmtContext ctx);
	/**
	 * Exit a parse tree produced by the {@code printlnStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 */
	void exitPrintlnStmt(OFPParser.PrintlnStmtContext ctx);
	/**
	 * Enter a parse tree produced by the {@code callMethod}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterCallMethod(OFPParser.CallMethodContext ctx);
	/**
	 * Exit a parse tree produced by the {@code callMethod}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitCallMethod(OFPParser.CallMethodContext ctx);
	/**
	 * Enter a parse tree produced by the {@code strExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterStrExpr(OFPParser.StrExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code strExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitStrExpr(OFPParser.StrExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code charExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterCharExpr(OFPParser.CharExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code charExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitCharExpr(OFPParser.CharExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code comp}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterComp(OFPParser.CompContext ctx);
	/**
	 * Exit a parse tree produced by the {@code comp}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitComp(OFPParser.CompContext ctx);
	/**
	 * Enter a parse tree produced by the {@code negation}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterNegation(OFPParser.NegationContext ctx);
	/**
	 * Exit a parse tree produced by the {@code negation}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitNegation(OFPParser.NegationContext ctx);
	/**
	 * Enter a parse tree produced by the {@code intExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterIntExpr(OFPParser.IntExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code intExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitIntExpr(OFPParser.IntExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code length}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterLength(OFPParser.LengthContext ctx);
	/**
	 * Exit a parse tree produced by the {@code length}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitLength(OFPParser.LengthContext ctx);
	/**
	 * Enter a parse tree produced by the {@code newArray}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterNewArray(OFPParser.NewArrayContext ctx);
	/**
	 * Exit a parse tree produced by the {@code newArray}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitNewArray(OFPParser.NewArrayContext ctx);
	/**
	 * Enter a parse tree produced by the {@code addsub}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterAddsub(OFPParser.AddsubContext ctx);
	/**
	 * Exit a parse tree produced by the {@code addsub}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitAddsub(OFPParser.AddsubContext ctx);
	/**
	 * Enter a parse tree produced by the {@code parenthesis}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterParenthesis(OFPParser.ParenthesisContext ctx);
	/**
	 * Exit a parse tree produced by the {@code parenthesis}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitParenthesis(OFPParser.ParenthesisContext ctx);
	/**
	 * Enter a parse tree produced by the {@code floatExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterFloatExpr(OFPParser.FloatExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code floatExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitFloatExpr(OFPParser.FloatExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code multdiv}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterMultdiv(OFPParser.MultdivContext ctx);
	/**
	 * Exit a parse tree produced by the {@code multdiv}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitMultdiv(OFPParser.MultdivContext ctx);
	/**
	 * Enter a parse tree produced by the {@code arrayAccess}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterArrayAccess(OFPParser.ArrayAccessContext ctx);
	/**
	 * Exit a parse tree produced by the {@code arrayAccess}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitArrayAccess(OFPParser.ArrayAccessContext ctx);
	/**
	 * Enter a parse tree produced by the {@code boolExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterBoolExpr(OFPParser.BoolExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code boolExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitBoolExpr(OFPParser.BoolExprContext ctx);
	/**
	 * Enter a parse tree produced by the {@code idExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void enterIdExpr(OFPParser.IdExprContext ctx);
	/**
	 * Exit a parse tree produced by the {@code idExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 */
	void exitIdExpr(OFPParser.IdExprContext ctx);
	/**
	 * Enter a parse tree produced by {@link OFPParser#print}.
	 * @param ctx the parse tree
	 */
	void enterPrint(OFPParser.PrintContext ctx);
	/**
	 * Exit a parse tree produced by {@link OFPParser#print}.
	 * @param ctx the parse tree
	 */
	void exitPrint(OFPParser.PrintContext ctx);
	/**
	 * Enter a parse tree produced by {@link OFPParser#println}.
	 * @param ctx the parse tree
	 */
	void enterPrintln(OFPParser.PrintlnContext ctx);
	/**
	 * Exit a parse tree produced by {@link OFPParser#println}.
	 * @param ctx the parse tree
	 */
	void exitPrintln(OFPParser.PrintlnContext ctx);
	/**
	 * Enter a parse tree produced by {@link OFPParser#arrayAssign}.
	 * @param ctx the parse tree
	 */
	void enterArrayAssign(OFPParser.ArrayAssignContext ctx);
	/**
	 * Exit a parse tree produced by {@link OFPParser#arrayAssign}.
	 * @param ctx the parse tree
	 */
	void exitArrayAssign(OFPParser.ArrayAssignContext ctx);
	/**
	 * Enter a parse tree produced by {@link OFPParser#arrayAcces}.
	 * @param ctx the parse tree
	 */
	void enterArrayAcces(OFPParser.ArrayAccesContext ctx);
	/**
	 * Exit a parse tree produced by {@link OFPParser#arrayAcces}.
	 * @param ctx the parse tree
	 */
	void exitArrayAcces(OFPParser.ArrayAccesContext ctx);
	/**
	 * Enter a parse tree produced by {@link OFPParser#methodCall}.
	 * @param ctx the parse tree
	 */
	void enterMethodCall(OFPParser.MethodCallContext ctx);
	/**
	 * Exit a parse tree produced by {@link OFPParser#methodCall}.
	 * @param ctx the parse tree
	 */
	void exitMethodCall(OFPParser.MethodCallContext ctx);
}