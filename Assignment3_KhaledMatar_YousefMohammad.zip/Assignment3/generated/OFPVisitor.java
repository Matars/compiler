// Generated from /Users/matar/School/compiler/Assignment3/OFP.g4 by ANTLR 4.13.1
    // Define name of package for generated Java files. 
    package generated;

import org.antlr.v4.runtime.tree.ParseTreeVisitor;

/**
 * This interface defines a complete generic visitor for a parse tree produced
 * by {@link OFPParser}.
 *
 * @param <T> The return type of the visit operation. Use {@link Void} for
 * operations with no return type.
 */
public interface OFPVisitor<T> extends ParseTreeVisitor<T> {
	/**
	 * Visit a parse tree produced by {@link OFPParser#start}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStart(OFPParser.StartContext ctx);
	/**
	 * Visit a parse tree produced by {@link OFPParser#mainFunc}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMainFunc(OFPParser.MainFuncContext ctx);
	/**
	 * Visit a parse tree produced by {@link OFPParser#methodFunc}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMethodFunc(OFPParser.MethodFuncContext ctx);
	/**
	 * Visit a parse tree produced by {@link OFPParser#stmtBlock}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStmtBlock(OFPParser.StmtBlockContext ctx);
	/**
	 * Visit a parse tree produced by {@link OFPParser#argList}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArgList(OFPParser.ArgListContext ctx);
	/**
	 * Visit a parse tree produced by {@link OFPParser#exprList}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitExprList(OFPParser.ExprListContext ctx);
	/**
	 * Visit a parse tree produced by the {@code assignStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAssignStmt(OFPParser.AssignStmtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code declareStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDeclareStmt(OFPParser.DeclareStmtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code declareAssignStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitDeclareAssignStmt(OFPParser.DeclareAssignStmtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code arrayAccessStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArrayAccessStmt(OFPParser.ArrayAccessStmtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code arrayAssignStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArrayAssignStmt(OFPParser.ArrayAssignStmtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code ifStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIfStmt(OFPParser.IfStmtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code whileStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitWhileStmt(OFPParser.WhileStmtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code returnStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitReturnStmt(OFPParser.ReturnStmtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code callMethodStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCallMethodStmt(OFPParser.CallMethodStmtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code printStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPrintStmt(OFPParser.PrintStmtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code printlnStmt}
	 * labeled alternative in {@link OFPParser#stmt}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPrintlnStmt(OFPParser.PrintlnStmtContext ctx);
	/**
	 * Visit a parse tree produced by the {@code callMethod}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCallMethod(OFPParser.CallMethodContext ctx);
	/**
	 * Visit a parse tree produced by the {@code strExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitStrExpr(OFPParser.StrExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code charExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitCharExpr(OFPParser.CharExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code comp}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitComp(OFPParser.CompContext ctx);
	/**
	 * Visit a parse tree produced by the {@code negation}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNegation(OFPParser.NegationContext ctx);
	/**
	 * Visit a parse tree produced by the {@code intExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIntExpr(OFPParser.IntExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code length}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitLength(OFPParser.LengthContext ctx);
	/**
	 * Visit a parse tree produced by the {@code newArray}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitNewArray(OFPParser.NewArrayContext ctx);
	/**
	 * Visit a parse tree produced by the {@code addsub}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitAddsub(OFPParser.AddsubContext ctx);
	/**
	 * Visit a parse tree produced by the {@code parenthesis}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitParenthesis(OFPParser.ParenthesisContext ctx);
	/**
	 * Visit a parse tree produced by the {@code floatExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitFloatExpr(OFPParser.FloatExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code multdiv}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMultdiv(OFPParser.MultdivContext ctx);
	/**
	 * Visit a parse tree produced by the {@code arrayAccess}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArrayAccess(OFPParser.ArrayAccessContext ctx);
	/**
	 * Visit a parse tree produced by the {@code boolExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitBoolExpr(OFPParser.BoolExprContext ctx);
	/**
	 * Visit a parse tree produced by the {@code idExpr}
	 * labeled alternative in {@link OFPParser#expr}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitIdExpr(OFPParser.IdExprContext ctx);
	/**
	 * Visit a parse tree produced by {@link OFPParser#print}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPrint(OFPParser.PrintContext ctx);
	/**
	 * Visit a parse tree produced by {@link OFPParser#println}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitPrintln(OFPParser.PrintlnContext ctx);
	/**
	 * Visit a parse tree produced by {@link OFPParser#arrayAssign}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArrayAssign(OFPParser.ArrayAssignContext ctx);
	/**
	 * Visit a parse tree produced by {@link OFPParser#arrayAcces}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitArrayAcces(OFPParser.ArrayAccesContext ctx);
	/**
	 * Visit a parse tree produced by {@link OFPParser#methodCall}.
	 * @param ctx the parse tree
	 * @return the visitor result
	 */
	T visitMethodCall(OFPParser.MethodCallContext ctx);
}