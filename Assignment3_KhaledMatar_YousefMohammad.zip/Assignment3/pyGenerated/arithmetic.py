#
# Program entry point - main
#
if __name__ == '__main__':
    pass
    pass
    pass
    p = 2
    q = p+2
    r = p+q*3
    print(r, end='\n')
    a = (1.0+2.0)-0.2345
    b = a+2.0
    c = a+b*3.0
    print(c, end='\n')
