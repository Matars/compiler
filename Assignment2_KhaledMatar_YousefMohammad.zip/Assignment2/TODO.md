funciton reutrn correct type but hash value not the same? must compare strings instead
